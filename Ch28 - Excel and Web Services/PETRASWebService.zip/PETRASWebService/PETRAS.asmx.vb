'Description:   Web Service for the practical example from Chapter 28 - Excel and Web Services.
'               Implements the web service to connect to the PETRAS database
'               providing an interface to the database over the web. This allows
'               Excel to be used as a rich client of the web service, both
'               retrieving the static lists at startup and posting timesheet data.
'
'Authors:       Rob Bovey, www.appspro.com
'               Stephen Bullen, www.oaltd.co.uk
'               
Imports System.Web.Services

<System.Web.Services.WebService( _
    Namespace:="http://www.appspro.com/PETRASWeb/PETRAS", _
    Description:="Web service for the Professional Excel Timesheet Reporting and Analysis System")> _
Public Class PETRAS
    Inherits System.Web.Services.WebService

    'Change this to be the path and file name of the PETRAS database
    Public msDATABASE As String = "D:\Files\PED\Ch28\Application\PETRAS.mdb"

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GetConsultants As System.Data.OleDb.OleDbCommand
    Friend WithEvents GetActivities As System.Data.OleDb.OleDbCommand
    Friend WithEvents GetClients As System.Data.OleDb.OleDbCommand
    Friend WithEvents GetProjects As System.Data.OleDb.OleDbCommand
    Friend WithEvents conPETRASDbConnection As System.Data.OleDb.OleDbConnection
    Friend WithEvents daConsultants As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents daActivities As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents daClients As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents daProjects As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents cmDeleteTime As System.Data.OleDb.OleDbCommand
    Friend WithEvents cmInsertTime As System.Data.OleDb.OleDbCommand

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PETRAS))
        Me.conPETRASDbConnection = New System.Data.OleDb.OleDbConnection
        Me.daConsultants = New System.Data.OleDb.OleDbDataAdapter
        Me.GetConsultants = New System.Data.OleDb.OleDbCommand
        Me.daActivities = New System.Data.OleDb.OleDbDataAdapter
        Me.GetActivities = New System.Data.OleDb.OleDbCommand
        Me.daClients = New System.Data.OleDb.OleDbDataAdapter
        Me.GetClients = New System.Data.OleDb.OleDbCommand
        Me.daProjects = New System.Data.OleDb.OleDbDataAdapter
        Me.GetProjects = New System.Data.OleDb.OleDbCommand
        Me.cmDeleteTime = New System.Data.OleDb.OleDbCommand
        Me.cmInsertTime = New System.Data.OleDb.OleDbCommand
        '
        'conPETRASDbConnection
        '
        Me.conPETRASDbConnection.ConnectionString = resources.GetString("conPETRASDbConnection.ConnectionString")
        '
        'daConsultants
        '
        Me.daConsultants.SelectCommand = Me.GetConsultants
        Me.daConsultants.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Consultant", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ConsultantID", "ID"), New System.Data.Common.DataColumnMapping("Expr1", "Name")})})
        '
        'GetConsultants
        '
        Me.GetConsultants.CommandText = "SELECT ConsultantID, FirstName + ' ' + LastName AS Expr1 FROM Consultants"
        Me.GetConsultants.Connection = Me.conPETRASDbConnection
        '
        'daActivities
        '
        Me.daActivities.SelectCommand = Me.GetActivities
        Me.daActivities.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Activity", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ActivityID", "ID"), New System.Data.Common.DataColumnMapping("ActivityName", "Name")})})
        '
        'GetActivities
        '
        Me.GetActivities.CommandText = "SELECT ActivityID, ActivityName FROM Activities"
        Me.GetActivities.Connection = Me.conPETRASDbConnection
        '
        'daClients
        '
        Me.daClients.SelectCommand = Me.GetClients
        Me.daClients.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Client", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ClientName", "Name"), New System.Data.Common.DataColumnMapping("ClientID", "ID")})})
        '
        'GetClients
        '
        Me.GetClients.CommandText = "SELECT ClientID, ClientName FROM Clients"
        Me.GetClients.Connection = Me.conPETRASDbConnection
        '
        'daProjects
        '
        Me.daProjects.SelectCommand = Me.GetProjects
        Me.daProjects.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Project", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ProjectID", "ID"), New System.Data.Common.DataColumnMapping("ProjectName", "Name"), New System.Data.Common.DataColumnMapping("ClientID", "ID_0")})})
        '
        'GetProjects
        '
        Me.GetProjects.CommandText = "SELECT ClientID, ProjectID, ProjectName FROM Projects"
        Me.GetProjects.Connection = Me.conPETRASDbConnection
        '
        'cmDeleteTime
        '
        Me.cmDeleteTime.CommandText = "DELETE FROM BillableHours WHERE (ConsultantID = prmConsultantID) AND (DateWorked " & _
            ">= prmWeekStart) AND (DateWorked <= prmWeekEnd)"
        Me.cmDeleteTime.Connection = Me.conPETRASDbConnection
        Me.cmDeleteTime.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("prmConsultantID", System.Data.OleDb.OleDbType.[Integer]), New System.Data.OleDb.OleDbParameter("prmWeekStart", System.Data.OleDb.OleDbType.DBDate), New System.Data.OleDb.OleDbParameter("prmWeekEnd", System.Data.OleDb.OleDbType.DBDate)})
        '
        'cmInsertTime
        '
        Me.cmInsertTime.CommandText = "INSERT INTO BillableHours (ConsultantID, DateWorked, ProjectID, ActivityID, Hours" & _
            ") VALUES (prmConsultantID, prmDateWorked, prmProjectID, prmActivityID, prmHours)" & _
            ""
        Me.cmInsertTime.Connection = Me.conPETRASDbConnection
        Me.cmInsertTime.Parameters.AddRange(New System.Data.OleDb.OleDbParameter() {New System.Data.OleDb.OleDbParameter("prmConsultantID", System.Data.OleDb.OleDbType.[Integer]), New System.Data.OleDb.OleDbParameter("prmDateWorked", System.Data.OleDb.OleDbType.DBDate), New System.Data.OleDb.OleDbParameter("prmProjectID", System.Data.OleDb.OleDbType.[Integer]), New System.Data.OleDb.OleDbParameter("prmActivityID", System.Data.OleDb.OleDbType.[Integer]), New System.Data.OleDb.OleDbParameter("prmHours", System.Data.OleDb.OleDbType.[Double])})

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region

    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    ' Comments: Provides the full set of static data as an XML file
    '           that conforms to the StaticData.wsd format
    '
    ' Returns:      String          The XML file
    '
    ' Date          Developer       Chap    Action
    ' --------------------------------------------------------------
    ' 12/23/08      Rob Bovey       Ch28    Initial version
    '
    <WebMethod(Description:="Provides all the static data for the PETRAS Time Sheet")> _
    Public Function GetStaticData() As String

        'Declare an instance of our StaticData data set,
        'which was generated by .NET from the xsd
        Dim dsStatic As New StaticData

        'Set the connection string
        Me.conPETRASDbConnection.ConnectionString = _
            "Provider=""Microsoft.Jet.OLEDB.4.0"";Data Source=""" & msDATABASE & """;"

        Try
            'Clear the data set
            dsStatic.Clear()

            'Fill each section of the data set
            daConsultants.Fill(dsStatic)
            daActivities.Fill(dsStatic)
            daClients.Fill(dsStatic)
            daProjects.Fill(dsStatic)

            'Return the resulting XML
            Return dsStatic.GetXml

        Catch ex As Exception
            Return ex.Message
        End Try

    End Function

    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    ' Comments: Accepts the XML string representing a full time sheet
    '           submittal, according to the TimeSheet.wsd format.
    '           Writes the information to the central database
    '
    ' Arguments:    sTimesheet      The XML file containing the timesheet data
    '
    ' Returns:      String          A confirmation or error message
    '
    ' Date          Developer       Chap    Action
    ' --------------------------------------------------------------
    ' 12/23/08      Rob Bovey       Ch28    Initial version
    '
    <WebMethod(Description:="Writes time sheet data to the central database")> _
        Public Function StoreTimeSheet(ByVal sTimesheet As String) As String

        Dim dsTimeSheet As New PETRASTimeSheet
        Dim iConsultant As Integer
        Dim dtWeekEnding As Date
        Dim bhRow As PETRASTimeSheet.BillableHoursRow

        Try
            'Read the text into the data set and validate it
            dsTimeSheet.ReadXml(New System.IO.StringReader(sTimesheet))

        Catch ex As Exception
            Return ex.Message
        End Try

        'Get the consultant ID and week ending
        iConsultant = dsTimeSheet.Consultant(0).ID
        dtWeekEnding = dsTimeSheet.TimeSheet(0).WeekEnding

        Try

            'Open the database connection
            conPETRASDbConnection.ConnectionString = "Provider=""Microsoft.Jet.OLEDB.4.0"";Data Source=""" & msDATABASE & """;User ID=Admin;Password=;"
            conPETRASDbConnection.Open()

            Try

                'Clear any existing data for this consultant and week
                With cmDeleteTime
                    .Parameters("prmConsultantID").Value = iConsultant
                    .Parameters("prmWeekStart").Value = dtWeekEnding.AddDays(-6)
                    .Parameters("prmWeekEnd").Value = dtWeekEnding
                    .ExecuteNonQuery()
                End With

                'Loop through the billable hours, adding them to the table
                With cmInsertTime
                    .Parameters("prmConsultantID").Value = iConsultant

                    For Each bhRow In dsTimeSheet.BillableHours.Rows
                        .Parameters("prmDateWorked").Value = bhRow.DateWorked
                        .Parameters("prmProjectID").Value = bhRow.ProjectID
                        .Parameters("prmActivityID").Value = bhRow.ActivityID
                        .Parameters("prmHours").Value = bhRow.Hours
                        .ExecuteNonQuery()
                    Next
                End With

                'Return an OK message, identifying the number of rows inserted
                Return "OK:" & dsTimeSheet.BillableHours.Rows.Count & " row(s) inserted for " & dsTimeSheet.Consultant(0).Name

            Catch ex As Exception
                Return "ERR:" & ex.Message
            Finally
                'Close the connection when we're done!
                conPETRASDbConnection.Close()
            End Try

        Catch ex As Exception
            Return "ERR:" & ex.Message
        End Try
    End Function

End Class