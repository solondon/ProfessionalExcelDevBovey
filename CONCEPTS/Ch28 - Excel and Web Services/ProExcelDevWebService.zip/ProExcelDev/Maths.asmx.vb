﻿'The Professional Excel Development Maths Web Service
Imports System.Web.Services

<System.Web.Services.WebService( _
 Namespace:="http://tempuri.org/ProExcelDev/Maths", _
    Description:="Pro Excel Dev Maths Functions")> _
Public Class Maths
    Inherits System.Web.Services.WebService

    'Add two numbers    
    <WebMethod(Description:="Adds two numbers")> _
    Public Function AddTwo(ByVal d1 As Double, _
            ByVal d2 As Double) As Double
        Return d1 + d2
    End Function

    'Multiply two numbers    
    <WebMethod(Description:="Multiplies two numbers")> _
    Public Function MultiplyTwo(ByVal d1 As Double, _
            ByVal d2 As Double) As Double
        Return d1 * d2
    End Function

End Class